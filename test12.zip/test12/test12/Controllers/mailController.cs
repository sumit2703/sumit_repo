﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MimeKit;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Configuration;

namespace test12.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class mailController : ControllerBase
    {
        IConfiguration _iconfiguration;
        public mailController(IConfiguration iconfiguration)
        {
            _iconfiguration = iconfiguration;
        }

        // GET: api/mail
        [HttpGet]
        public IEnumerable<string> Get()
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("user name", "email"));//provide user name and email
            message.To.Add(new MailboxAddress("user name", "email"));
            message.Subject = "How you doin?";
            var builder = new BodyBuilder();
            // var webRoot = _env.WebRootPath; //get wwwroot Folder
            using (StreamReader SourceReader = System.IO.File.OpenText("wwwroot/mailTemp/mailpage.html"))
            {
                builder.HtmlBody = SourceReader.ReadToEnd();
            }
            message.Body = builder.ToMessageBody();
            using (var client = new MailKit.Net.Smtp.SmtpClient())
            {
                client.Connect("smtp.gmail.com", 465);
                client.Authenticate(_iconfiguration["email"], _iconfiguration["password"]);
                // give details in appsetting.json
                client.Send(message);
                client.Disconnect(true);

            }
            return new string[] { "value1", "value2" };
        }

        // GET: api/mail/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/mail
        [HttpPost]
        public void Post([FromBody] string value)
        {

        }

        // PUT: api/mail/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
          


            // We may also want to attach a calendar event for Monica's party...
            // builder.Attachments.Add(@"C:\Users\Joey\Documents\party.ics");

            // Now we just need to set the message body and we're done

        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
